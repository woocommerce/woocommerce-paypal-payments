<?php
/**
 * Plugin Name: Negative 12 Fee
 * 
 * Description: Adds a fixed cart fee of -12.
 */
defined( 'ABSPATH' ) || exit;
 
add_action(
	'woocommerce_cart_calculate_fees',
	static function ( $cart ) {
		if ( is_admin() && ! wp_doing_ajax() ) {
			return;
		}
 
		if ( ! $cart instanceof WC_Cart || $cart->is_empty() ) {
			return;
		}
		$cart->add_fee( 'negative12Fee', -12, false );
	},
	10,
	1
);
 