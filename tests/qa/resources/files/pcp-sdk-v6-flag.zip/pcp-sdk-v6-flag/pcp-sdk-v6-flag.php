<?php
/**
 * Plugin Name:       PCP SDK v6 Feature Flag
 * Description:        Enables the PayPal SDK v6 feature flag in WooCommerce PayPal Payments via the WooCommerce feature-flags filter.
 * Version:           1.0.0
 * Requires PHP:      7.4
 * Author:            QA
 * License:           GPL-2.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_filter( 'woocommerce.feature-flags.woocommerce_paypal_payments.sdk_v6_enabled', '__return_true' );
