<?php
/**
 * Plugin Name: Enable New PCP UI
 */
add_filter('woocommerce.feature-flags.woocommerce_paypal_payments.settings_enabled', '__return_true');