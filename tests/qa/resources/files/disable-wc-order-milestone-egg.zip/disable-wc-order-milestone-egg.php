<?php
/**
 * Plugin Name: Disable WC Order Milestone Egg
 *
 * WooCommerce celebrates order milestones with a full screen dialog. The suite
 * resets the database, so every run's first order is order number one and the
 * dialog appears reliably - and as an aria-modal overlay it swallows pointer
 * events, failing the next admin click until the test times out.
 */
add_filter( 'wc_order_milestone_egg_enabled', '__return_false' );
