<?php
/**
 * Plugin Name: Disable webhook verification
 */
if ( ! defined( 'PAYPAL_WEBHOOK_REQUEST_VERIFICATION' ) ) {
	define( 'PAYPAL_WEBHOOK_REQUEST_VERIFICATION', false );
}
