<?php
/**
 * Plugin Name:       PCP SDK Version Flag
 * Description:       QA-only override for the PayPal SDK v6 feature flag, toggled via a REST
 *                     endpoint instead of plugin activation state. Independent of the
 *                     PCP_SDK_V6_ENABLED server env var and any production default, so it keeps
 *                     working on environments where that env var is already forced on.
 * Version:           2.0.0
 * Requires PHP:      7.4
 * Author:            QA
 * License:           GPL-2.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'PCP_QA_SDK_V6_OPTION', 'pcp_qa_sdk_v6_enabled' );

// Overrides the flag unconditionally while this plugin is active — ignores the passed-in
// default (env var / production fresh-install logic) so QA can force either version
// regardless of what the environment would otherwise choose.
add_filter(
	'woocommerce.feature-flags.woocommerce_paypal_payments.sdk_v6_enabled',
	function () {
		return '1' === get_option( PCP_QA_SDK_V6_OPTION, '0' );
	}
);

add_action(
	'rest_api_init',
	function () {
		register_rest_route(
			'pcp-qa/v1',
			'/sdk-v6',
			array(
				'methods'             => 'POST',
				'callback'            => function ( WP_REST_Request $request ) {
					$enabled = (bool) $request->get_param( 'enabled' );
					update_option( PCP_QA_SDK_V6_OPTION, $enabled ? '1' : '0' );
					return array( 'enabled' => $enabled );
				},
				// manage_options (not manage_woocommerce): this route is called by the
				// setup step that runs before WooCommerce's own activation is confirmed
				// on the current run, and manage_woocommerce only resolves once WC has
				// registered it — this stays a plain WP-admin check instead.
				'permission_callback' => function () {
					return current_user_can( 'manage_options' );
				},
			)
		);
	}
);
