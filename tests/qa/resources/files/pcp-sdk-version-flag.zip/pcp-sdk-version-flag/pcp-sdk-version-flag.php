<?php
/**
 * Plugin Name:       PCP SDK Version Flag
 * Description:       QA-only v5 switch for the PayPal JS SDK. SDK v6 is PCP's default; while
 *                     v5 is requested via the REST endpoint, the sdk_v6_enabled feature flag is
 *                     forced off. Also reports which SDK version the site actually loads.
 * Version:           3.0.0
 * Requires PHP:      7.4
 * Author:            QA
 * License:           GPL-2.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'PCP_QA_SDK_VERSION_OPTION', 'pcp_qa_sdk_version' );
define( 'PCP_QA_SDK_V6_FLAG', 'woocommerce.feature-flags.woocommerce_paypal_payments.sdk_v6_enabled' );

// Forces v5 only when requested; otherwise PCP's own default decides.
add_filter(
	PCP_QA_SDK_V6_FLAG,
	function ( $enabled ) {
		return 'v5' === get_option( PCP_QA_SDK_VERSION_OPTION ) ? false : $enabled;
	},
	PHP_INT_MAX - 1
);

// Records the final flag value PCP loads its modules with, for the GET endpoint.
add_filter(
	PCP_QA_SDK_V6_FLAG,
	function ( $enabled ) {
		$GLOBALS['pcp_qa_sdk_v6_loaded'] = (bool) $enabled;
		return $enabled;
	},
	PHP_INT_MAX
);

add_action(
	'rest_api_init',
	function () {
		register_rest_route(
			'pcp-qa/v1',
			'/sdk-version',
			array(
				array(
					'methods'             => 'POST',
					'callback'            => function ( WP_REST_Request $request ) {
						if ( 'v5' === $request->get_param( 'version' ) ) {
							update_option( PCP_QA_SDK_VERSION_OPTION, 'v5' );
						} else {
							delete_option( PCP_QA_SDK_VERSION_OPTION );
						}
						return array( 'requested' => get_option( PCP_QA_SDK_VERSION_OPTION ) ?: 'default' );
					},
					'permission_callback' => 'pcp_qa_sdk_version_permission',
				),
				array(
					'methods'             => 'GET',
					'callback'            => function () {
						// Null when PCP didn't evaluate the flag in this request (e.g. inactive).
						$loaded = $GLOBALS['pcp_qa_sdk_v6_loaded'] ?? null;
						return array(
							'version' => null === $loaded ? null : ( $loaded ? 'v6' : 'v5' ),
						);
					},
					'permission_callback' => 'pcp_qa_sdk_version_permission',
				),
			)
		);
	}
);

/**
 * Plain WP-admin check: the POST runs before WooCommerce's activation is confirmed
 * on the current run, and manage_woocommerce only resolves once WC has registered it.
 */
function pcp_qa_sdk_version_permission(): bool {
	return current_user_can( 'manage_options' );
}
