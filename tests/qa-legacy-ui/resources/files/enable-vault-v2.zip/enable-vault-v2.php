<?php
/**
* Plugin Name: Enable Vault v2
 */
add_filter('woocommerce.feature-flags.woocommerce_paypal_payments.save_payment_methods_enabled', '__return_false');
add_filter('woocommerce.feature-flags.woocommerce_paypal_payments.card_fields_enabled', '__return_false');