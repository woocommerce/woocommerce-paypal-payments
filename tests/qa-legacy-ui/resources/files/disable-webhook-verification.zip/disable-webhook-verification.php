<?php
/**
 * Plugin Name: Disable webhook verification
 */
const PAYPAL_WEBHOOK_REQUEST_VERIFICATION = false;