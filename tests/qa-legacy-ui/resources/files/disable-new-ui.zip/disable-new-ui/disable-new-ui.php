<?php
/**
 * Plugin Name: Disable new UI
 */
update_option( 'woocommerce-ppcp-is-new-merchant', 'no' );
update_option( 'woocommerce_ppcp-settings-should-use-old-ui', 'yes' );
